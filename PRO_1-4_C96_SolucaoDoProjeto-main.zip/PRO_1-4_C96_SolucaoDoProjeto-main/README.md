# spectagram-stage-2
project solution for c82
